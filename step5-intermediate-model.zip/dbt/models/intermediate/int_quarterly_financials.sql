-- One row per company per fiscal quarter, with each financial metric as a column.
--
-- Why this is not just "select the 3-month values":
--   * 10-K filings report the full year, not Q4, so Q4 must be derived.
--   * Cash-flow items (capex) are reported year-to-date: 3, 6, 9, 12 months.
-- So for every flow metric we take the year-to-date (YTD) values and subtract
-- the previous YTD value:  Q2 = 6-month YTD - 3-month YTD,  Q4 = 12-month - 9-month.

with facts as (

    select * from {{ ref('stg_sec_facts') }}
    where unit = 'USD'

),

-- 1. Map SEC tag names to our metric names. Some companies switched tags over the
--    years (e.g. Revenues -> RevenueFromContract...), so priority 1 wins when both exist.
tag_map as (

    select * from (values
        ('Revenues',                                            'revenue',          1),
        ('RevenueFromContractWithCustomerExcludingAssessedTax', 'revenue',          2),
        ('CostOfRevenue',                                       'cost_of_revenue',  1),
        ('CostOfGoodsAndServicesSold',                          'cost_of_revenue',  2),
        ('GrossProfit',                                         'gross_profit',     1),
        ('OperatingIncomeLoss',                                 'operating_income', 1),
        ('NetIncomeLoss',                                       'net_income',       1),
        ('ResearchAndDevelopmentExpense',                       'rnd_expense',      1),
        ('PaymentsToAcquirePropertyPlantAndEquipment',          'capex',            1),
        ('InventoryNet',                                        'inventory',        1)
    ) as t (tag, metric, priority)

),

metric_facts as (

    select f.cik, f.ticker, m.metric, f.period_start, f.period_end, f.period_type, f.value
    from facts f
    join tag_map m on f.tag = m.tag
    qualify row_number() over (
        partition by f.cik, m.metric, f.period_start, f.period_end
        order by m.priority
    ) = 1

),

-- 2. Find each company's fiscal years from its annual revenue rows.
completed_years as (

    select cik, period_start as fy_start, period_end as fy_end
    from metric_facts
    where metric = 'revenue' and period_type = 'year'

),

-- The year in progress has no annual row yet: it starts the day after the last year ended.
current_year as (

    select cik,
           dateadd(day, 1,   max(fy_end)) as fy_start,
           dateadd(day, 365, max(fy_end)) as fy_end
    from completed_years
    group by cik

),

fiscal_years as (

    select * from completed_years
    union all
    select * from current_year

),

-- 3. Flow metrics: keep the YTD rows (those that start on the fiscal-year start),
--    then subtract the previous YTD value to get each quarter on its own.
flows_ytd as (

    select
        m.cik, m.ticker, m.metric, y.fy_start, y.fy_end, m.period_end,
        m.value as ytd_value,
        least(4, greatest(1, round(datediff(day, y.fy_start, m.period_end) / 91.25)))::int as fiscal_quarter
    from metric_facts m
    join fiscal_years y
      on m.cik = y.cik
     and m.period_start = y.fy_start
     and m.period_end  <= y.fy_end
    where m.metric <> 'inventory'

),

flows as (

    select
        cik, ticker, metric, fy_end, period_end, fiscal_quarter,
        case
            -- if a YTD value is missing (e.g. no 6-month figure), the difference
            -- would cover two quarters, so leave it empty instead of being wrong
            when fiscal_quarter - coalesce(lag(fiscal_quarter) over (partition by cik, metric, fy_start order by period_end), 0) = 1
            then ytd_value - coalesce(lag(ytd_value) over (partition by cik, metric, fy_start order by period_end), 0)
        end as value
    from flows_ytd

),

-- 4. Balance-sheet metrics (inventory) are a snapshot on the quarter-end date: no subtraction.
instants as (

    select
        m.cik, m.ticker, m.metric, y.fy_end, m.period_end,
        least(4, greatest(1, round(datediff(day, y.fy_start, m.period_end) / 91.25)))::int as fiscal_quarter,
        m.value
    from metric_facts m
    join fiscal_years y
      on m.cik = y.cik
     and m.period_end >= y.fy_start
     and m.period_end <= y.fy_end
    where m.metric = 'inventory'

),

all_metrics as (

    select * from flows
    union all
    select * from instants

),

-- 5. Pivot: one row per company-quarter, one column per metric.
pivoted as (

    select
        cik,
        ticker,
        year(fy_end)       as fiscal_year,
        fiscal_quarter,
        max(period_end)    as period_end,
        max(case when metric = 'revenue'          then value end) as revenue,
        max(case when metric = 'cost_of_revenue'  then value end) as cost_of_revenue,
        max(case when metric = 'gross_profit'     then value end) as gross_profit_reported,
        max(case when metric = 'operating_income' then value end) as operating_income,
        max(case when metric = 'net_income'       then value end) as net_income,
        max(case when metric = 'rnd_expense'      then value end) as rnd_expense,
        max(case when metric = 'capex'            then value end) as capex,
        max(case when metric = 'inventory'        then value end) as inventory
    from all_metrics
    group by 1, 2, 3, 4

)

select
    cik || '-' || fiscal_year || '-Q' || fiscal_quarter               as company_quarter_id,
    cik,
    ticker,
    fiscal_year,
    fiscal_quarter,
    period_end,
    -- calendar quarter containing the middle of the fiscal quarter, so companies with
    -- different fiscal years (Micron ends ~Sep, Marvell ~Jan) line up on one timeline
    date_trunc('quarter', dateadd(day, -45, period_end))::date       as calendar_quarter,
    revenue,
    cost_of_revenue,
    coalesce(gross_profit_reported, revenue - cost_of_revenue)        as gross_profit,
    operating_income,
    net_income,
    rnd_expense,
    capex,
    inventory
from pivoted
where revenue is not null
